export interface UserProgress {
  isPremium: boolean;
  streak: number;
  xp: number;
  totalSessions: number;
  bestScore: number;
  completedChallenges: string[];
  lastSessionDate: string | null;
}

export interface ChallengeQuestion {
  id: number;
  a: number;
  b: number;
  operator: string;
  correctAnswer: number;
  options: number[];
  category: string;
}

export interface SessionResult {
  score: number;
  accuracy: number;
  avgSpeed: number;
  xpGained: number;
  streak: number;
  category: string;
  duration: number;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: string;
  period: string;
  badge?: string;
  features: string[];
  isPopular?: boolean;
  isBestValue?: boolean;
  isLifetime?: boolean;
}
