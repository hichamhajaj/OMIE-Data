import AsyncStorage from '@react-native-async-storage/async-storage';

export const STORAGE_KEYS = {
  IS_PREMIUM: 'synaptic_is_premium',
  STREAK: 'synaptic_streak',
  XP: 'synaptic_xp',
  TOTAL_SESSIONS: 'synaptic_total_sessions',
  BEST_SCORE: 'synaptic_best_score',
  COMPLETED_CHALLENGES: 'synaptic_completed_challenges',
  LAST_SESSION_DATE: 'synaptic_last_session',
};

export const saveData = async (key: string, value: any): Promise<void> => {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('Error saving data:', error);
  }
};

export const loadData = async <T>(key: string, defaultValue: T): Promise<T> => {
  try {
    const value = await AsyncStorage.getItem(key);
    return value ? JSON.parse(value) : defaultValue;
  } catch (error) {
    console.error('Error loading data:', error);
    return defaultValue;
  }
};
