import React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { theme } from '../lib/theme';

interface GlassCardProps {
  children: React.ReactNode;
  style?: ViewStyle;
  glow?: boolean;
  border?: boolean;
}

export default function GlassCard({ children, style, glow = false, border = true }: GlassCardProps) {
  return (
    <View
      style={[
        styles.card,
        border && styles.border,
        glow && styles.glow,
        style,
      ]}
    >
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'rgba(23, 31, 51, 0.6)',
    borderRadius: theme.radius.lg,
    padding: theme.spacing.lg,
    overflow: 'hidden',
  },
  border: {
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.1)',
  },
  glow: {
    shadowColor: theme.colors.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.2,
    shadowRadius: 20,
    elevation: 10,
  },
});
