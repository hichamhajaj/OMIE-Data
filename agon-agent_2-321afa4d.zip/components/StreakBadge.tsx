import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { theme } from '../lib/theme';
import { Ionicons } from '@expo/vector-icons';

interface StreakBadgeProps {
  streak: number;
}

export default function StreakBadge({ streak }: StreakBadgeProps) {
  return (
    <View style={styles.container}>
      <View style={styles.inner}>
        <Ionicons name="flame" size={14} color={theme.colors.primary} />
        <Text style={styles.text}>{streak} 🔥</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: theme.colors.surfaceContainerHigh,
    borderRadius: 999,
    padding: 8,
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.1)',
  },
  inner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  text: {
    fontSize: 13,
    fontWeight: '700',
    color: theme.colors.primary,
  },
});
