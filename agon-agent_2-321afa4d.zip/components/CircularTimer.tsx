import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Svg, { Circle } from 'react-native-svg';
import { theme } from '../lib/theme';

interface CircularTimerProps {
  timeLeft: number;
  totalTime: number;
}

export default function CircularTimer({ timeLeft, totalTime }: CircularTimerProps) {
  const radius = 88;
  const circumference = 2 * Math.PI * radius;
  const progress = (timeLeft / totalTime) * circumference;
  const strokeDashoffset = circumference - progress;

  return (
    <View style={styles.container}>
      <Svg width={192} height={192} style={styles.svg}>
        <Circle
          cx={96}
          cy={96}
          r={radius}
          fill="transparent"
          stroke={theme.colors.surfaceContainerHighest}
          strokeWidth={4}
        />
        <Circle
          cx={96}
          cy={96}
          r={radius}
          fill="transparent"
          stroke={theme.colors.primaryFixedDim}
          strokeWidth={6}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          transform="rotate(-90 96 96)"
        />
      </Svg>
      <View style={styles.content}>
        <Text style={styles.time}>{formatTime(timeLeft)}</Text>
        <Text style={styles.label}>Seconds Left</Text>
      </View>
    </View>
  );
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

const styles = StyleSheet.create({
  container: {
    width: 192,
    height: 192,
    alignItems: 'center',
    justifyContent: 'center',
  },
  svg: {
    position: 'absolute',
  },
  content: {
    alignItems: 'center',
  },
  time: {
    fontSize: 48,
    fontWeight: '900',
    color: theme.colors.onSurface,
    letterSpacing: -2,
  },
  label: {
    fontSize: 10,
    fontWeight: '600',
    color: theme.colors.outline,
    letterSpacing: 1,
    marginTop: 4,
  },
});
