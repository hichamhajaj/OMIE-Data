import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { theme } from '../lib/theme';

interface AdBannerProps {
  onPress?: () => void;
}

export default function AdBanner({ onPress }: AdBannerProps) {
  return (
    <View style={styles.container}>
      <View style={styles.adLabel}>
        <Text style={styles.adText}>Ad</Text>
      </View>
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <Text style={styles.icon}>🧠</Text>
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.title}>NeuroHealth Analytics</Text>
          <Text style={styles.subtitle}>Smarter recovery for peak performance.</Text>
        </View>
        <TouchableOpacity style={styles.installButton} onPress={onPress}>
          <Text style={styles.installText}>Install</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    maxWidth: 360,
    height: 56,
    backgroundColor: theme.colors.surfaceContainerLowest,
    borderRadius: theme.radius.md,
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.1)',
    overflow: 'hidden',
    position: 'relative',
  },
  adLabel: {
    position: 'absolute',
    top: 4,
    left: 4,
    backgroundColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: 4,
    paddingVertical: 1,
    borderRadius: 2,
  },
  adText: {
    fontSize: 8,
    fontWeight: '600',
    color: theme.colors.onSurfaceVariant,
    opacity: 0.5,
    letterSpacing: 0.5,
  },
  content: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
    gap: 12,
  },
  iconContainer: {
    width: 32,
    height: 32,
    backgroundColor: theme.colors.surfaceContainerHigh,
    borderRadius: theme.radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    fontSize: 16,
  },
  textContainer: {
    flex: 1,
  },
  title: {
    fontSize: 10,
    fontWeight: '700',
    color: theme.colors.onSurfaceVariant,
  },
  subtitle: {
    fontSize: 9,
    color: 'rgba(199, 196, 215, 0.5)',
  },
  installButton: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 999,
  },
  installText: {
    fontSize: 10,
    fontWeight: '700',
    color: theme.colors.onSurface,
  },
});
