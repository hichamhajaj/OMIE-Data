import React from 'react';
import { TouchableOpacity, Text, View, StyleSheet } from 'react-native';
import { theme } from '../lib/theme';
import { Ionicons } from '@expo/vector-icons';

interface AnswerButtonProps {
  answer: number;
  state: 'normal' | 'correct' | 'wrong';
  onPress: () => void;
  disabled?: boolean;
}

export default function AnswerButton({ answer, state, onPress, disabled }: AnswerButtonProps) {
  const getStyle = () => {
    switch (state) {
      case 'correct':
        return [styles.button, styles.correct];
      case 'wrong':
        return [styles.button, styles.wrong];
      default:
        return [styles.button];
    }
  };

  const getTextColor = () => {
    switch (state) {
      case 'correct':
        return theme.colors.success;
      case 'wrong':
        return 'rgba(218, 226, 253, 0.6)';
      default:
        return theme.colors.onSurface;
    }
  };

  return (
    <TouchableOpacity
      style={getStyle()}
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.9}
    >
      <Text style={[styles.text, { color: getTextColor() }]}>{answer}</Text>
      {state === 'correct' && (
        <View style={styles.checkmark}>
          <Ionicons name="checkmark-circle" size={18} color={theme.colors.success} />
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: theme.colors.surfaceContainerHighest,
    borderRadius: theme.radius.md,
    padding: 32,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.1)',
  },
  correct: {
    borderColor: 'rgba(16, 185, 129, 0.5)',
    borderWidth: 2,
    shadowColor: '#10b981',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.2,
    shadowRadius: 20,
  },
  wrong: {
    borderColor: 'rgba(255, 180, 171, 0.2)',
    backgroundColor: 'rgba(255, 180, 171, 0.05)',
  },
  text: {
    fontSize: 28,
    fontWeight: '700',
    letterSpacing: -1,
  },
  checkmark: {
    position: 'absolute',
    top: 12,
    right: 12,
  },
});
