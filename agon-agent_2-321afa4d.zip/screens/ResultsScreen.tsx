import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView } from 'react-native';
import { theme } from '../lib/theme';
import GlassCard from '../components/GlassCard';
import GradientButton from '../components/GradientButton';
import { useApp } from '../context/AppContext';
import { hapticMedium } from '../lib/haptics';
import { Ionicons } from '@expo/vector-icons';

interface ResultsScreenProps {
  result: {
    score: number;
    accuracy: number;
    avgSpeed: number;
    xpGained: number;
  };
  onContinue: () => void;
  onUpgrade: () => void;
}

export default function ResultsScreen({ result, onContinue, onUpgrade }: ResultsScreenProps) {
  const { isPremium } = useApp();

  const isGoodScore = result.score >= 80;
  const percentile = Math.min(99, Math.floor(result.accuracy * 0.8) + 20);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.backgroundGlows}>
        <View style={styles.glow1} />
        <View style={styles.glow2} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.headerSection}>
          <Text style={styles.sessionComplete}>Training Session Complete</Text>
          <Text style={styles.sessionTitle}>{isGoodScore ? 'Peak Performance' : 'Great Effort'}</Text>
        </View>

        {/* Score Grid */}
        <View style={styles.scoreGrid}>
          <GlassCard style={styles.mainScoreCard} glow>
            <Text style={styles.scoreLabel}>Total Score</Text>
            <Text style={styles.scoreValue}>{Math.round(result.score * 100)}</Text>
            <View style={styles.trendRow}>
              <Ionicons name="trending-up" size={20} color={theme.colors.secondary} />
              <Text style={[styles.trendText, { color: theme.colors.secondary }]}>+12% vs last session</Text>
            </View>
          </GlassCard>

          <GlassCard style={styles.smallCard}>
            <Text style={styles.smallLabel}>Accuracy</Text>
            <Text style={styles.smallValue}>{result.accuracy}%</Text>
            <View style={styles.progressTrack}>
              <View style={[styles.progressFill, { width: `${result.accuracy}%` }]} />
            </View>
          </GlassCard>

          <GlassCard style={styles.smallCard}>
            <Text style={styles.smallLabel}>Avg Speed</Text>
            <Text style={styles.smallValue}>{result.avgSpeed}s</Text>
            <Text style={styles.smallSub}>Blazing Fast</Text>
          </GlassCard>

          <GlassCard style={styles.xpCard}>
            <View style={styles.xpRow}>
              <View style={styles.xpIcon}>
                <Ionicons name="star" size={24} color={theme.colors.primary} />
              </View>
              <View>
                <Text style={styles.xpLabel}>XP Gained</Text>
                <Text style={styles.xpValue}>+{result.xpGained} XP</Text>
              </View>
            </View>
            <TouchableOpacity style={styles.claimButton}>
              <Text style={styles.claimText}>CLAIM REWARD</Text>
            </TouchableOpacity>
          </GlassCard>
        </View>

        {/* Analytics */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View>
              <Text style={styles.sectionTitle}>Advanced Analytics</Text>
              <Text style={styles.sectionSubtitle}>Weekly Synaptic Efficiency</Text>
            </View>
            {!isPremium && <Text style={styles.lockedText}>Limited</Text>}
          </View>

          <GlassCard>
            <View style={styles.chartContainer}>
              {[0.6, 0.45, 0.75, 0.9, 0.65, 0.8, 0.85].map((height, i) => (
                <View key={i} style={[styles.bar, { height: `${height * 100}%` }]} />
              ))}
            </View>
            <View style={styles.chartLabels}>
              {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map((d, i) => (
                <Text key={i} style={styles.chartLabel}>{d}</Text>
              ))}
            </View>
          </GlassCard>
        </View>

        {/* Premium Upsell (Free only) */}
        {!isPremium && (
          <View style={styles.upsellSection}>
            <GlassCard>
              <View style={styles.upsellContent}>
                <Text style={styles.upsellTitle}>Deeper Analytics</Text>
                <Text style={styles.upsellDesc}>
                  Unlock sub-frequency wave breakdowns and circadian rhythm alignment.
                </Text>
                <TouchableOpacity
                  style={styles.upsellButton}
                  onPress={onUpgrade}
                >
                  <Ionicons name="trophy" size={16} color={theme.colors.onPrimaryContainer} />
                  <Text style={styles.upsellButtonText}>Unlock Advanced Analysis</Text>
                </TouchableOpacity>
              </View>
            </GlassCard>
          </View>
        )}
      </ScrollView>

      <View style={styles.bottomActions}>
        <GradientButton
          title="Continue to Dashboard"
          onPress={() => {
            hapticMedium();
            onContinue();
          }}
          style={{ width: '100%' }}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  backgroundGlows: {
    position: 'absolute',
    inset: 0,
  },
  glow1: {
    position: 'absolute',
    top: -80,
    right: -80,
    width: 400,
    height: 400,
    backgroundColor: 'rgba(208, 188, 255, 0.15)',
    borderRadius: 999,
  },
  glow2: {
    position: 'absolute',
    bottom: -80,
    left: -80,
    width: 480,
    height: 480,
    backgroundColor: 'rgba(5, 102, 217, 0.15)',
    borderRadius: 999,
  },
  scrollContent: {
    paddingBottom: 140,
  },
  headerSection: {
    alignItems: 'center',
    paddingTop: 40,
    paddingHorizontal: theme.spacing.lg,
  },
  sessionComplete: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.colors.primaryFixedDim,
    letterSpacing: 2,
    textTransform: 'uppercase',
  },
  sessionTitle: {
    fontSize: 48,
    fontWeight: '900',
    color: theme.colors.onSurface,
    letterSpacing: -2,
    textAlign: 'center',
    marginTop: 8,
  },
  scoreGrid: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: 32,
    gap: 12,
  },
  mainScoreCard: {
    padding: 32,
    marginBottom: 8,
  },
  scoreLabel: {
    fontSize: 14,
    fontWeight: '500',
    color: theme.colors.onSurfaceVariant,
  },
  scoreValue: {
    fontSize: 64,
    fontWeight: '900',
    color: theme.colors.primary,
    letterSpacing: -2,
    marginTop: 4,
  },
  trendRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 12,
  },
  trendText: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.secondaryFixedDim,
  },
  smallCard: {
    padding: 24,
  },
  smallLabel: {
    fontSize: 11,
    fontWeight: '500',
    color: theme.colors.onSurfaceVariant,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  smallValue: {
    fontSize: 24,
    fontWeight: '800',
    color: theme.colors.onSurface,
    marginTop: 4,
  },
  smallSub: {
    fontSize: 10,
    color: 'rgba(199, 196, 215, 0.6)',
    marginTop: 4,
  },
  progressTrack: {
    height: 4,
    backgroundColor: theme.colors.surfaceContainerLowest,
    borderRadius: 999,
    marginTop: 12,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: theme.colors.primary,
    shadowColor: theme.colors.primary,
    shadowOpacity: 0.5,
    shadowRadius: 4,
  },
  xpCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 24,
    backgroundColor: 'rgba(23, 31, 51, 0.8)',
  },
  xpRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  xpIcon: {
    width: 48,
    height: 48,
    borderRadius: 999,
    backgroundColor: 'rgba(208, 188, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  xpLabel: {
    fontSize: 11,
    fontWeight: '500',
    color: theme.colors.onSurfaceVariant,
  },
  xpValue: {
    fontSize: 20,
    fontWeight: '800',
    color: theme.colors.onSurface,
  },
  claimButton: {
    backgroundColor: theme.colors.primary,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 999,
  },
  claimText: {
    fontSize: 12,
    fontWeight: '700',
    color: theme.colors.onPrimary,
  },
  section: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: theme.colors.onSurface,
  },
  sectionSubtitle: {
    fontSize: 13,
    color: theme.colors.onSurfaceVariant,
    marginTop: 2,
  },
  lockedText: {
    fontSize: 11,
    fontWeight: '700',
    color: theme.colors.outline,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  chartContainer: {
    height: 140,
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    paddingHorizontal: 8,
  },
  bar: {
    width: 28,
    backgroundColor: theme.colors.secondaryContainer,
    borderRadius: 999,
  },
  chartLabels: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 8,
    marginTop: 16,
  },
  chartLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: theme.colors.onSurfaceVariant,
    letterSpacing: 0.5,
  },
  upsellSection: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: 32,
  },
  upsellContent: {
    alignItems: 'center',
  },
  upsellTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.onSurface,
    marginBottom: 8,
  },
  upsellDesc: {
    fontSize: 14,
    color: theme.colors.onSurfaceVariant,
    textAlign: 'center',
    marginBottom: 24,
    maxWidth: 280,
  },
  upsellButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: theme.colors.primary,
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: theme.radius.md,
    width: '100%',
  },
  upsellButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: theme.colors.onPrimaryContainer,
  },
  bottomActions: {
    position: 'absolute',
    bottom: 40,
    left: theme.spacing.lg,
    right: theme.spacing.lg,
  },
});
