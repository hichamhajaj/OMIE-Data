import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { theme } from '../lib/theme';
import GradientButton from '../components/GradientButton';
import { hapticMedium } from '../lib/haptics';

interface OnboardingScreenProps {
  onGetStarted: () => void;
  onLogin: () => void;
}

export default function OnboardingScreen({ onGetStarted, onLogin }: OnboardingScreenProps) {
  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.backgroundGlows}>
        <View style={styles.glowTop} />
        <View style={styles.glowBottom} />
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={styles.brandRow}>
            <View style={styles.brandBar} />
            <Text style={styles.brand}>Synaptic Flow</Text>
          </View>
          <Text style={styles.tagline}>Elevate your cognitive potential</Text>
        </View>

        <View style={styles.visualContainer}>
          <View style={styles.brainVisual}>
            <Text style={styles.brainEmoji}>🧠</Text>
            <View style={styles.pulseRing} />
          </View>
        </View>

        <View style={styles.textContent}>
          <Text style={styles.title}>
            Train your brain with{'\n'}precision challenges
          </Text>
          <Text style={styles.subtitle}>
            Advanced neural feedback for high-performance minds.
            Unlock deep analytics and specialized training modes.
          </Text>
        </View>

        <View style={styles.proofContainer}>
          <View style={styles.proofBadge}>
            <Text style={styles.proofText}>92% of premium users train more consistently</Text>
          </View>
        </View>
      </ScrollView>

      <View style={styles.bottomActions}>
        <GradientButton
          title="Get Started"
          onPress={() => {
            hapticMedium();
            onGetStarted();
          }}
          style={styles.primaryButton}
        />
        <TouchableOpacity onPress={onLogin} style={styles.secondaryButton}>
          <Text style={styles.secondaryText}>Already have an account? <Text style={styles.loginLink}>Log in</Text></Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  backgroundGlows: {
    position: 'absolute',
    inset: 0,
  },
  glowTop: {
    position: 'absolute',
    top: -80,
    left: -80,
    width: 300,
    height: 300,
    backgroundColor: 'rgba(208, 188, 255, 0.1)',
    borderRadius: 999,
  },
  glowBottom: {
    position: 'absolute',
    bottom: -80,
    right: -80,
    width: 280,
    height: 280,
    backgroundColor: 'rgba(173, 198, 255, 0.1)',
    borderRadius: 999,
  },
  content: {
    flexGrow: 1,
    paddingHorizontal: theme.spacing.lg,
    paddingTop: 60,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  brandBar: {
    width: 8,
    height: 32,
    backgroundColor: theme.colors.primary,
    borderRadius: 999,
  },
  brand: {
    fontSize: 28,
    fontWeight: '900',
    color: theme.colors.primary,
    letterSpacing: -1,
  },
  tagline: {
    fontSize: 16,
    color: theme.colors.onSurfaceVariant,
    marginTop: 12,
    textAlign: 'center',
  },
  visualContainer: {
    alignItems: 'center',
    marginVertical: 40,
  },
  brainVisual: {
    width: 140,
    height: 140,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  brainEmoji: {
    fontSize: 80,
  },
  pulseRing: {
    position: 'absolute',
    width: 160,
    height: 160,
    borderRadius: 999,
    borderWidth: 2,
    borderColor: theme.colors.primary,
    opacity: 0.3,
  },
  textContent: {
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: '800',
    color: theme.colors.onSurface,
    textAlign: 'center',
    lineHeight: 38,
    marginBottom: 16,
  },
  subtitle: {
    fontSize: 15,
    color: theme.colors.onSurfaceVariant,
    textAlign: 'center',
    lineHeight: 22,
  },
  proofContainer: {
    marginTop: 32,
    alignItems: 'center',
  },
  proofBadge: {
    backgroundColor: 'rgba(208, 188, 255, 0.1)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(208, 188, 255, 0.2)',
  },
  proofText: {
    fontSize: 11,
    fontWeight: '700',
    color: theme.colors.primary,
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  bottomActions: {
    padding: theme.spacing.lg,
    paddingBottom: 40,
  },
  primaryButton: {
    width: '100%',
    marginBottom: 16,
  },
  secondaryButton: {
    alignItems: 'center',
  },
  secondaryText: {
    color: theme.colors.onSurfaceVariant,
    fontSize: 14,
  },
  loginLink: {
    color: theme.colors.primaryFixedDim,
    fontWeight: '600',
  },
});
