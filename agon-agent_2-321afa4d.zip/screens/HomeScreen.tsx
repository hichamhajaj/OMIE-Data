import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView } from 'react-native';
import { theme } from '../lib/theme';
import GlassCard from '../components/GlassCard';
import AdBanner from '../components/AdBanner';
import StreakBadge from '../components/StreakBadge';
import GradientButton from '../components/GradientButton';
import { useApp } from '../context/AppContext';
import { hapticMedium, hapticLight } from '../lib/haptics';
import { Ionicons } from '@expo/vector-icons';

interface HomeScreenProps {
  onStartChallenge: () => void;
  onOpenPremium: () => void;
  onOpenProfile: () => void;
}

export default function HomeScreen({ onStartChallenge, onOpenPremium, onOpenProfile }: HomeScreenProps) {
  const { user, isPremium } = useApp();
  const [selectedCategory, setSelectedCategory] = useState('Memory');

  const categories = [
    { id: 'Focus', icon: 'center_focus_strong', label: 'Focus', count: 12, locked: false },
    { id: 'Memory', icon: 'psychology', label: 'Memory', count: 8, locked: false },
    { id: 'Logic', icon: 'account_tree', label: 'Logic', count: 15, locked: true },
    { id: 'Reflex', icon: 'flash', label: 'Neuro Reflex', count: 10, locked: true },
  ];

  const recentActivity = [
    { id: 1, title: 'Sustained Attention', time: 'Yesterday', duration: '14m', delta: '+12%', type: 'theta' },
    { id: 2, title: 'Pattern Matrix', time: '2 days ago', duration: '8m', delta: '+8%', type: 'theta' },
  ];

  const unlockedCategories = categories.filter(c => !c.locked);
  const lockedCategories = categories.filter(c => c.locked);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <TouchableOpacity style={styles.avatar} onPress={onOpenProfile}>
              <Text style={styles.avatarEmoji}>👤</Text>
            </TouchableOpacity>
            <Text style={styles.appName}>Synaptic Flow</Text>
          </View>
          <StreakBadge streak={user.streak} />
        </View>

        {/* Daily Challenge Hero */}
        <View style={styles.heroContainer}>
          <TouchableOpacity activeOpacity={0.9} onPress={onStartChallenge}>
            <View style={styles.hero}>
              <View style={styles.heroOverlay} />
              <View style={styles.heroContent}>
                <View style={styles.heroBadge}>
                  <Text style={styles.heroBadgeText}>Daily Challenge</Text>
                </View>
                <Text style={styles.heroTitle}>Neural{'\n'}Nexus</Text>
                <Text style={styles.heroSubtitle}>
                  Enhance cognitive plasticity through complex pattern matching.
                </Text>
                <GradientButton
                  title="Start Session"
                  onPress={() => {
                    hapticMedium();
                    onStartChallenge();
                  }}
                  style={styles.heroButton}
                />
              </View>
            </View>
          </TouchableOpacity>
        </View>

        {/* Ad Banner (Free only) */}
        {!isPremium && (
          <View style={styles.adContainer}>
            <AdBanner onPress={() => hapticLight()} />
          </View>
        )}

        {/* Categories */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Training Categories</Text>
          <View style={styles.categoriesGrid}>
            {unlockedCategories.map((cat, index) => (
              <TouchableOpacity
                key={cat.id}
                style={styles.categoryCard}
                onPress={() => {
                  setSelectedCategory(cat.id);
                  hapticLight();
                }}
              >
                <Ionicons name={cat.icon as any} size={32} color={theme.colors.primary} />
                <View style={styles.categoryInfo}>
                  <Text style={styles.categoryLabel}>{cat.label}</Text>
                  <Text style={styles.categoryCount}>{cat.count} Exercises</Text>
                </View>
              </TouchableOpacity>
            ))}
            {lockedCategories.map((cat) => (
              <TouchableOpacity
                key={cat.id}
                style={styles.categoryCardLocked}
                onPress={onOpenPremium}
              >
                <View style={styles.lockOverlay}>
                  <Ionicons name="lock-closed" size={24} color={theme.colors.onSurfaceVariant} />
                </View>
                <Ionicons name={cat.icon as any} size={32} color="rgba(208, 188, 255, 0.4)" />
                <View style={styles.categoryInfo}>
                  <Text style={styles.categoryLabelLocked}>{cat.label}</Text>
                  <Text style={styles.categoryCountLocked}>Premium Only</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Upgrade Card (Free only) */}
        {!isPremium && (
          <View style={styles.upgradeContainer}>
            <GlassCard glow>
              <View style={styles.upgradeContent}>
                <View style={styles.upgradeIcon}>
                  <Ionicons name="trophy" size={28} color={theme.colors.primary} />
                </View>
                <Text style={styles.upgradeTitle}>Unlock the Full{'\n'}Neural Potential</Text>
                <Text style={styles.upgradeDesc}>
                  Get advanced biofeedback, 40+ specialized training modes, and detailed synaptic trend analysis.
                </Text>
                <TouchableOpacity
                  style={styles.upgradeButton}
                  onPress={() => {
                    hapticMedium();
                    onOpenPremium();
                  }}
                >
                  <Text style={styles.upgradeButtonText}>Upgrade to Premium</Text>
                </TouchableOpacity>
                <Text style={styles.upgradeTrial}>7-Day Free Trial Available</Text>
              </View>
            </GlassCard>
          </View>
        )}

        {/* Recent Activity */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Flow</Text>
            <TouchableOpacity>
              <Text style={styles.seeAll}>See All</Text>
            </TouchableOpacity>
          </View>
          {recentActivity.map((activity, index) => (
            <GlassCard key={index} style={styles.activityCard}>
              <View style={styles.activityRow}>
                <View style={styles.activityIcon}>
                  <Ionicons name="timer" size={24} color={theme.colors.primary} />
                </View>
                <View style={styles.activityInfo}>
                  <Text style={styles.activityTitle}>{activity.title}</Text>
                  <Text style={styles.activityMeta}>{activity.time} • {activity.duration} Session</Text>
                </View>
                <View style={styles.activityDelta}>
                  <Text style={styles.deltaValue}>{activity.delta}</Text>
                  <Text style={styles.deltaLabel}>Delta</Text>
                </View>
              </View>
            </GlassCard>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  scrollContent: {
    paddingBottom: 120,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.lg,
    paddingTop: theme.spacing.md,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 999,
    backgroundColor: theme.colors.surfaceContainerHigh,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(208, 188, 255, 0.2)',
  },
  avatarEmoji: {
    fontSize: 18,
  },
  appName: {
    fontSize: 18,
    fontWeight: '900',
    color: theme.colors.primary,
    letterSpacing: -0.5,
  },
  heroContainer: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: theme.spacing.lg,
  },
  hero: {
    height: 260,
    backgroundColor: theme.colors.surfaceContainer,
    borderRadius: theme.radius.lg,
    overflow: 'hidden',
    position: 'relative',
  },
  heroOverlay: {
    position: 'absolute',
    inset: 0,
    backgroundColor: 'rgba(11, 19, 38, 0.6)',
  },
  heroContent: {
    padding: 32,
    flex: 1,
    justifyContent: 'flex-end',
  },
  heroBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(208, 188, 255, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(208, 188, 255, 0.3)',
    marginBottom: 12,
  },
  heroBadgeText: {
    fontSize: 10,
    fontWeight: '700',
    color: theme.colors.primary,
    letterSpacing: 1,
  },
  heroTitle: {
    fontSize: 42,
    fontWeight: '900',
    color: '#fff',
    lineHeight: 44,
    letterSpacing: -1,
    marginBottom: 8,
  },
  heroSubtitle: {
    fontSize: 14,
    color: theme.colors.onSurfaceVariant,
    maxWidth: 200,
    marginBottom: 16,
  },
  heroButton: {
    alignSelf: 'flex-start',
  },
  adContainer: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: theme.spacing.lg,
    alignItems: 'center',
  },
  section: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: theme.spacing.xl,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.onSurface,
  },
  seeAll: {
    fontSize: 12,
    fontWeight: '700',
    color: theme.colors.primary,
    letterSpacing: 1,
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  categoryCard: {
    width: '48%',
    aspectRatio: 1,
    backgroundColor: theme.colors.surfaceContainerHigh,
    borderRadius: theme.radius.lg,
    padding: 24,
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.1)',
  },
  categoryCardLocked: {
    width: '48%',
    aspectRatio: 1,
    backgroundColor: 'rgba(23, 31, 51, 0.4)',
    borderRadius: theme.radius.lg,
    padding: 24,
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.05)',
    position: 'relative',
    overflow: 'hidden',
  },
  lockOverlay: {
    position: 'absolute',
    inset: 0,
    backgroundColor: 'rgba(6, 14, 32, 0.5)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1,
  },
  categoryInfo: {
    marginTop: 'auto',
  },
  categoryLabel: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.onSurface,
    marginBottom: 4,
  },
  categoryLabelLocked: {
    fontSize: 18,
    fontWeight: '700',
    color: 'rgba(218, 226, 253, 0.4)',
    marginBottom: 4,
  },
  categoryCount: {
    fontSize: 12,
    color: 'rgba(199, 196, 215, 0.6)',
  },
  categoryCountLocked: {
    fontSize: 12,
    color: 'rgba(199, 196, 215, 0.3)',
  },
  upgradeContainer: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: theme.spacing.xl,
  },
  upgradeContent: {
    alignItems: 'flex-start',
  },
  upgradeIcon: {
    width: 48,
    height: 48,
    borderRadius: 999,
    backgroundColor: 'rgba(208, 188, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  upgradeTitle: {
    fontSize: 24,
    fontWeight: '800',
    color: theme.colors.onSurface,
    marginBottom: 8,
    lineHeight: 28,
  },
  upgradeDesc: {
    fontSize: 14,
    color: theme.colors.onSurfaceVariant,
    lineHeight: 20,
    marginBottom: 20,
  },
  upgradeButton: {
    width: '100%',
    backgroundColor: theme.colors.onSurface,
    paddingVertical: 16,
    borderRadius: theme.radius.md,
    alignItems: 'center',
  },
  upgradeButtonText: {
    color: theme.colors.surface,
    fontSize: 16,
    fontWeight: '700',
  },
  upgradeTrial: {
    fontSize: 10,
    color: theme.colors.outline,
    fontWeight: '600',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginTop: 12,
    alignSelf: 'center',
  },
  activityCard: {
    marginBottom: 12,
  },
  activityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  activityIcon: {
    width: 48,
    height: 48,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.05)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  activityInfo: {
    flex: 1,
  },
  activityTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: theme.colors.onSurface,
  },
  activityMeta: {
    fontSize: 12,
    color: theme.colors.onSurfaceVariant,
    marginTop: 4,
  },
  activityDelta: {
    alignItems: 'flex-end',
  },
  deltaValue: {
    fontSize: 16,
    fontWeight: '800',
    color: theme.colors.primary,
  },
  deltaLabel: {
    fontSize: 10,
    color: 'rgba(199, 196, 215, 0.4)',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
});
