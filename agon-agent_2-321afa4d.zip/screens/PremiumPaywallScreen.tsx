import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView } from 'react-native';
import { theme } from '../lib/theme';
import GlassCard from '../components/GlassCard';
import GradientButton from '../components/GradientButton';
import { useApp } from '../context/AppContext';
import { hapticMedium, hapticSuccess } from '../lib/haptics';
import { SubscriptionPlan } from '../lib/types';
import { Ionicons } from '@expo/vector-icons';

interface PremiumPaywallScreenProps {
  onSubscribe: (planId: string) => void;
  onRestore: () => void;
  onContinueFree: () => void;
}

export default function PremiumPaywallScreen({ onSubscribe, onRestore, onContinueFree }: PremiumPaywallScreenProps) {
  const { setPremium } = useApp();

  const plans: SubscriptionPlan[] = [
    {
      id: 'weekly',
      name: 'Weekly',
      price: '$4.99',
      period: '/wk',
      features: ['Remove Ads', 'Unlimited Challenges'],
    },
    {
      id: 'annual',
      name: 'Annual',
      price: '$59.99',
      period: '/yr',
      badge: 'Most Popular',
      isBestValue: true,
      isPopular: true,
      features: ['Remove Ads', 'Unlimited Challenges', 'Advanced Analytics', 'Deep Focus Lab'],
    },
    {
      id: 'lifetime',
      name: 'Lifetime',
      price: '$149.99',
      period: '',
      isLifetime: true,
      features: ['All Premium Features', 'Luxury Access Forever'],
    },
  ];

  const handleSubscribe = (plan: SubscriptionPlan) => {
    hapticSuccess();
    setPremium(true);
    onSubscribe(plan.id);
  };

  const handleRestore = () => {
    hapticMedium();
    setPremium(true);
    onRestore();
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.heroSection}>
          <View style={styles.premiumBadge}>
            <Ionicons name="trophy" size={16} color={theme.colors.primary} />
            <Text style={styles.premiumBadgeText}>Elevate Your Mind</Text>
          </View>
          <Text style={styles.heroTitle}>Unlock Your Peak Potential.</Text>
          <Text style={styles.heroSubtitle}>
            Experience neural optimization with our most advanced cognitive tools and deep analytics.
          </Text>
          <View style={styles.proofBadge}>
            <Ionicons name="flash" size={12} color={theme.colors.primary} />
            <Text style={styles.proofText}>92% of premium users train more consistently</Text>
          </View>
        </View>

        {/* Pricing Plans */}
        <View style={styles.plansSection}>
          {plans.map((plan, index) => {
            const isPopular = plan.isPopular;
            const isLifetime = plan.isLifetime;
            return (
              <View key={plan.id} style={[styles.planCard, isPopular && styles.popularPlan]}>
                {isPopular && (
                  <View style={styles.popularBadge}>
                    <Text style={styles.popularBadgeText}>Most Popular</Text>
                  </View>
                )}
                {plan.isBestValue && (
                  <View style={styles.bestValueBadge}>
                    <Text style={styles.bestValueText}>Best Value</Text>
                  </View>
                )}

                <Text style={[styles.planName, isPopular && styles.planNamePopular]}>{plan.name}</Text>
                <View style={styles.priceRow}>
                  <Text style={[styles.price, isPopular && styles.pricePopular]}>{plan.price}</Text>
                  <Text style={styles.period}>{plan.period}</Text>
                </View>
                {plan.isBestValue && (
                  <Text style={styles.savings}>Save 75% compared to weekly</Text>
                )}

                <View style={styles.featuresList}>
                  {plan.features.map((feature, i) => (
                    <View key={i} style={styles.featureItem}>
                      <Ionicons
                        name="checkmark-circle"
                        size={16}
                        color={isPopular ? theme.colors.primary : theme.colors.primary}
                        style={{ fontVariationSettings: "'FILL' 1" }}
                      />
                      <Text style={[styles.featureText, isPopular && styles.featureTextPopular]}>{feature}</Text>
                    </View>
                  ))}
                </View>

                <TouchableOpacity
                  style={[styles.planButton, isPopular && styles.planButtonPopular, isLifetime && styles.planButtonLifetime]}
                  onPress={() => handleSubscribe(plan)}
                >
                  <Text style={[styles.planButtonText, isPopular && styles.planButtonTextPopular]}>
                    {isLifetime ? 'One-time Investment' : isPopular ? 'Start Your Journey' : 'Select Plan'}
                  </Text>
                </TouchableOpacity>
              </View>
            );
          })}
        </View>

        {/* Premium Benefits */}
        <View style={styles.benefitsSection}>
          <View style={styles.benefitRow}>
            <Ionicons name="analytics" size={24} color={theme.colors.secondary} />
            <View style={styles.benefitText}>
              <Text style={styles.benefitTitle}>Advanced Analytics</Text>
              <Text style={styles.benefitDesc}>Real-time brain wave tracking and habit correlations.</Text>
            </View>
          </View>
          <View style={styles.benefitRow}>
            <Ionicons name="flask" size={24} color={theme.colors.secondary} />
            <View style={styles.benefitText}>
              <Text style={styles.benefitTitle}>Deep Focus Lab</Text>
              <Text style={styles.benefitDesc}>Exclusive binaural sessions for cognitive enhancement.</Text>
            </View>
          </View>
        </View>

        <View style={styles.actionsSection}>
          <TouchableOpacity onPress={handleRestore} style={styles.restoreButton}>
            <Text style={styles.restoreText}>Restore Purchase</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onContinueFree} style={styles.freeButton}>
            <Text style={styles.freeText}>Continue with Free Version</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.disclaimer}>
          Subscription automatically renews unless canceled at least 24 hours before the end of the current period. Management of subscriptions is available in your account settings.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  scrollContent: {
    paddingBottom: 60,
  },
  heroSection: {
    alignItems: 'center',
    paddingTop: 40,
    paddingHorizontal: theme.spacing.lg,
  },
  premiumBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 6,
    backgroundColor: theme.colors.surfaceContainerHigh,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(208, 188, 255, 0.15)',
    marginBottom: 16,
  },
  premiumBadgeText: {
    fontSize: 11,
    fontWeight: '700',
    color: theme.colors.primary,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  heroTitle: {
    fontSize: 36,
    fontWeight: '800',
    color: theme.colors.onSurface,
    textAlign: 'center',
    lineHeight: 40,
    marginBottom: 12,
  },
  heroSubtitle: {
    fontSize: 15,
    color: theme.colors.onSurfaceVariant,
    textAlign: 'center',
    maxWidth: 300,
    lineHeight: 22,
  },
  proofBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: 'rgba(208, 188, 255, 0.08)',
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(208, 188, 255, 0.2)',
  },
  proofText: {
    fontSize: 11,
    fontWeight: '700',
    color: theme.colors.primary,
    letterSpacing: 0.5,
  },
  plansSection: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: 40,
    gap: 16,
  },
  planCard: {
    backgroundColor: theme.colors.surfaceContainer,
    borderRadius: theme.radius.xl,
    padding: 32,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.1)',
    position: 'relative',
  },
  popularPlan: {
    backgroundColor: theme.colors.surfaceContainerHighest,
    borderColor: theme.colors.primary,
    borderWidth: 2,
    shadowColor: theme.colors.primary,
    shadowOpacity: 0.3,
    shadowRadius: 24,
    transform: [{ scale: 1.02 }],
  },
  popularBadge: {
    position: 'absolute',
    top: -14,
    alignSelf: 'center',
    backgroundColor: theme.colors.primary,
    paddingHorizontal: 20,
    paddingVertical: 6,
    borderRadius: 999,
    shadowColor: theme.colors.primary,
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  popularBadgeText: {
    fontSize: 10,
    fontWeight: '900',
    color: theme.colors.onPrimaryContainer,
    letterSpacing: 1,
  },
  bestValueBadge: {
    position: 'absolute',
    top: 20,
    alignSelf: 'center',
    backgroundColor: theme.colors.secondaryContainer,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 999,
  },
  bestValueText: {
    fontSize: 9,
    fontWeight: '700',
    color: '#fff',
    letterSpacing: 1,
  },
  planName: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.onSurfaceVariant,
    marginBottom: 16,
  },
  planNamePopular: {
    color: theme.colors.primary,
    fontSize: 20,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
    marginBottom: 4,
  },
  price: {
    fontSize: 32,
    fontWeight: '900',
    color: theme.colors.onSurface,
  },
  pricePopular: {
    fontSize: 48,
  },
  period: {
    fontSize: 16,
    color: theme.colors.onSurfaceVariant,
  },
  savings: {
    fontSize: 11,
    fontWeight: '700',
    color: theme.colors.primaryFixedDim,
    letterSpacing: 0.5,
    marginBottom: 24,
  },
  featuresList: {
    alignSelf: 'stretch',
    marginBottom: 24,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 10,
  },
  featureText: {
    fontSize: 13,
    color: theme.colors.onSurfaceVariant,
  },
  featureTextPopular: {
    color: theme.colors.onSurface,
  },
  planButton: {
    width: '100%',
    paddingVertical: 14,
    borderRadius: theme.radius.md,
    backgroundColor: theme.colors.surfaceContainerHighest,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.3)',
  },
  planButtonPopular: {
    backgroundColor: theme.colors.primary,
    shadowColor: theme.colors.primary,
    shadowOpacity: 0.4,
    shadowRadius: 16,
  },
  planButtonLifetime: {
    backgroundColor: 'rgba(219, 184, 255, 0.1)',
    borderColor: 'rgba(219, 184, 255, 0.3)',
  },
  planButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: theme.colors.onSurface,
  },
  planButtonTextPopular: {
    color: theme.colors.onPrimaryContainer,
    fontSize: 15,
  },
  benefitsSection: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: 40,
    gap: 16,
  },
  benefitRow: {
    flexDirection: 'row',
    gap: 16,
    padding: 20,
    backgroundColor: 'rgba(23, 31, 51, 0.5)',
    borderRadius: theme.radius.lg,
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.05)',
  },
  benefitText: {
    flex: 1,
  },
  benefitTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: theme.colors.onSurface,
    marginBottom: 4,
  },
  benefitDesc: {
    fontSize: 12,
    color: theme.colors.onSurfaceVariant,
    lineHeight: 18,
  },
  actionsSection: {
    alignItems: 'center',
    marginTop: 32,
    paddingHorizontal: theme.spacing.lg,
  },
  restoreButton: {
    paddingVertical: 12,
  },
  restoreText: {
    fontSize: 12,
    fontWeight: '700',
    color: theme.colors.primaryFixedDim,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  freeButton: {
    paddingVertical: 8,
  },
  freeText: {
    fontSize: 10,
    color: 'rgba(199, 196, 215, 0.4)',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  disclaimer: {
    fontSize: 10,
    color: 'rgba(199, 196, 215, 0.6)',
    textAlign: 'center',
    paddingHorizontal: 48,
    marginTop: 24,
    lineHeight: 16,
  },
});
