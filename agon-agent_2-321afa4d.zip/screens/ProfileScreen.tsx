import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, SafeAreaView } from 'react-native';
import { theme } from '../lib/theme';
import GlassCard from '../components/GlassCard';
import StreakBadge from '../components/StreakBadge';
import { useApp } from '../context/AppContext';
import { hapticMedium } from '../lib/haptics';
import { Ionicons } from '@expo/vector-icons';

interface ProfileScreenProps {
  onOpenPremium: () => void;
}

export default function ProfileScreen({ onOpenPremium }: ProfileScreenProps) {
  const { user, isPremium } = useApp();

  const achievements = [
    { id: 1, icon: 'bolt', label: 'Lightning\nReflexes', unlocked: true },
    { id: 2, icon: 'terminal', label: 'Code\nBreaker', unlocked: false },
    { id: 3, icon: 'eye', label: 'Pattern\nSeeker', unlocked: true },
    { id: 4, icon: 'sparkles', label: 'Zen\nState', unlocked: true },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <Text style={styles.brand}>Synaptic Flow</Text>
          </View>
          <StreakBadge streak={user.streak} />
        </View>

        {/* Profile Section */}
        <View style={styles.profileSection}>
          <View style={styles.avatarContainer}>
            <View style={styles.avatar}>
              <Text style={styles.avatarEmoji}>👤</Text>
            </View>
            {!isPremium && (
              <View style={styles.freeBadge}>
                <Text style={styles.freeBadgeText}>Free</Text>
              </View>
            )}
          </View>
          <Text style={styles.userName}>Alex Rivera</Text>
          <Text style={styles.userLevel}>Neuro-Explorer Level {Math.floor(user.streak / 2) + 3}</Text>
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <TouchableOpacity style={styles.statCard} activeOpacity={0.9}>
            <Ionicons name="flame" size={32} color={theme.colors.primary} />
            <Text style={styles.statValue}>{user.streak}</Text>
            <Text style={styles.statLabel}>Day Streak</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.statCard} activeOpacity={0.9}>
            <Ionicons name="flash" size={32} color={theme.colors.secondary} />
            <Text style={styles.statValue}>{user.xp}</Text>
            <Text style={styles.statLabel}>Total XP</Text>
          </TouchableOpacity>
        </View>

        {/* Skill Analysis */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Skill Analysis</Text>
          <View style={styles.skillGrid}>
            <GlassCard style={styles.skillCard} glow>
              <Text style={styles.skillLabel}>Strongest Skill</Text>
              <Text style={styles.skillName}>Memory</Text>
              <View style={styles.skillValueRow}>
                <Text style={styles.skillValue}>98</Text>
                <Text style={styles.skillPercentile}>Top 0.2%</Text>
              </View>
              <View style={styles.skillBar}>
                <View style={[styles.skillFill, { width: '98%' }]} />
              </View>
            </GlassCard>
            <GlassCard style={styles.skillCardWeak}>
              <Text style={styles.skillLabelWeak}>Area for Growth</Text>
              <Text style={styles.skillName}>Math</Text>
              <View style={styles.skillValueRow}>
                <Text style={styles.skillValueWeak}>64</Text>
                <Text style={styles.skillAvg}>Global Avg: 61</Text>
              </View>
              <TouchableOpacity style={styles.recoverButton} onPress={() => hapticMedium()}>
                <Text style={styles.recoverText}>Start Recovery Drill</Text>
                <Ionicons name="arrow-forward" size={14} color={theme.colors.primary} />
              </TouchableOpacity>
            </GlassCard>
          </View>
        </View>

        {/* Weekly Cognitive Graph (Premium only) */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Neural Load</Text>
            <Text style={styles.graphSub}>7-day Synaptic Variance</Text>
          </View>
          <GlassCard>
            <View style={styles.graphHeader}>
              <Text style={styles.graphTitle}>Neural Load</Text>
              <View style={styles.graphChange}>
                <Text style={styles.graphChangeValue}>+12.4%</Text>
                <Text style={styles.graphChangeLabel}>vs last week</Text>
              </View>
            </View>
            <View style={styles.graphBars}>
              {[40, 65, 55, 95, 70, 85, 45].map((h, i) => (
                <View key={i} style={styles.graphBarContainer}>
                  <View style={[styles.graphBar, { height: h }]} />
                  <Text style={styles.graphDay}>M T W T F S S</Text>
                </View>
              ))}
            </View>
          </GlassCard>
        </View>

        {/* Achievements */}
        <View style={styles.section}>
          <View style={styles.achHeader}>
            <Text style={styles.sectionTitle}>Achievements</Text>
            <View style={styles.achBadge}>
              <Text style={styles.achCount}>24 / 150</Text>
            </View>
          </View>
          <View style={styles.achGrid}>
            {achievements.map((ach) => (
              <View
                key={ach.id}
                style={[styles.achCard, !ach.unlocked && styles.achCardLocked]}
              >
                <Ionicons
                  name={ach.icon as any}
                  size={32}
                  color={ach.unlocked ? theme.colors.primary : theme.colors.onSurfaceVariant}
                />
                <Text style={[styles.achLabel, !ach.unlocked && styles.achLabelLocked]}>
                  {ach.label}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Premium CTA (Free only) */}
        {!isPremium && (
          <View style={styles.premiumSection}>
            <View style={styles.premiumGradient}>
              <View style={styles.premiumContent}>
                <View style={styles.premiumHeader}>
                  <Ionicons name="trophy" size={20} color="#fff" />
                  <Text style={styles.premiumBadge}>Premium Membership</Text>
                </View>
                <Text style={styles.premiumTitle}>Master the Flow of Your Mind.</Text>
                <View style={styles.premiumFeatures}>
                  {['Deep Synaptic Insights & Reports', 'Unlimited Neural Training Programs', 'Ad-free focused meditation cycles'].map((f, i) => (
                    <View key={i} style={styles.featureRow}>
                      <Ionicons name="checkmark-circle" size={14} color="rgba(255,255,255,0.9)" />
                      <Text style={styles.featureText}>{f}</Text>
                    </View>
                  ))}
                </View>
                <TouchableOpacity style={styles.premiumButton} onPress={onOpenPremium}>
                  <Text style={styles.premiumButtonText}>Go Premium — $9.99/mo</Text>
                </TouchableOpacity>
                <Text style={styles.premiumTrial}>Cancel Anytime • 7-Day Free Trial</Text>
              </View>
            </View>
          </View>
        )}

        {/* Settings */}
        <View style={styles.settingsSection}>
          {['Account Settings', 'Reminders & Alerts', 'Support Center'].map((s, i) => (
            <TouchableOpacity key={i} style={styles.settingRow} onPress={() => hapticMedium()}>
              <View style={styles.settingLeft}>
                <Ionicons name="settings" size={22} color={theme.colors.onSurfaceVariant} />
                <Text style={styles.settingText}>{s}</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={theme.colors.onSurfaceVariant} />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  scrollContent: {
    paddingBottom: 140,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.lg,
    paddingTop: 16,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  brand: {
    fontSize: 18,
    fontWeight: '900',
    color: theme.colors.primary,
    letterSpacing: -0.5,
  },
  profileSection: {
    alignItems: 'center',
    paddingTop: 24,
    paddingBottom: 16,
  },
  avatarContainer: {
    position: 'relative',
  },
  avatar: {
    width: 96,
    height: 96,
    borderRadius: 24,
    backgroundColor: theme.colors.surfaceContainerHigh,
    borderWidth: 2,
    borderColor: 'rgba(208, 188, 255, 0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  avatarEmoji: {
    fontSize: 48,
  },
  freeBadge: {
    position: 'absolute',
    bottom: -6,
    right: -6,
    backgroundColor: theme.colors.secondaryContainer,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 999,
    shadowColor: theme.colors.secondary,
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  freeBadgeText: {
    fontSize: 9,
    fontWeight: '700',
    color: '#fff',
    letterSpacing: 0.5,
  },
  userName: {
    fontSize: 26,
    fontWeight: '800',
    color: theme.colors.onSurface,
    marginTop: 16,
  },
  userLevel: {
    fontSize: 14,
    color: theme.colors.onSurfaceVariant,
    marginTop: 4,
  },
  statsGrid: {
    flexDirection: 'row',
    paddingHorizontal: theme.spacing.lg,
    gap: 12,
    marginTop: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: theme.colors.surfaceContainerHigh,
    padding: 24,
    borderRadius: theme.radius.lg,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 36,
    fontWeight: '900',
    color: theme.colors.onSurface,
    marginTop: 8,
  },
  statLabel: {
    fontSize: 11,
    color: theme.colors.onSurfaceVariant,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginTop: 4,
  },
  section: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: theme.colors.onSurface,
  },
  graphSub: {
    fontSize: 12,
    color: theme.colors.onSurfaceVariant,
  },
  skillGrid: {
    flexDirection: 'row',
    gap: 12,
  },
  skillCard: {
    flex: 1,
  },
  skillCardWeak: {
    flex: 1,
    backgroundColor: theme.colors.surfaceContainerLow,
  },
  skillLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: theme.colors.primary,
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  skillLabelWeak: {
    fontSize: 10,
    fontWeight: '600',
    color: theme.colors.error,
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  skillName: {
    fontSize: 28,
    fontWeight: '800',
    color: theme.colors.onSurface,
    marginTop: 4,
  },
  skillValueRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 8,
    marginTop: 8,
  },
  skillValue: {
    fontSize: 36,
    fontWeight: '900',
    color: theme.colors.onSurface,
  },
  skillValueWeak: {
    fontSize: 36,
    fontWeight: '900',
    color: theme.colors.onSurfaceVariant,
  },
  skillPercentile: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.secondary,
  },
  skillAvg: {
    fontSize: 12,
    color: theme.colors.onSurfaceVariant,
    opacity: 0.6,
  },
  skillBar: {
    height: 6,
    backgroundColor: theme.colors.surfaceContainerLowest,
    borderRadius: 999,
    marginTop: 12,
    overflow: 'hidden',
  },
  skillFill: {
    height: '100%',
    backgroundColor: theme.colors.primary,
    borderRadius: 999,
  },
  recoverButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 16,
  },
  recoverText: {
    fontSize: 12,
    fontWeight: '700',
    color: theme.colors.primary,
    letterSpacing: 0.5,
  },
  graphHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  graphTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: theme.colors.onSurface,
  },
  graphChange: {
    alignItems: 'flex-end',
  },
  graphChangeValue: {
    fontSize: 22,
    fontWeight: '900',
    color: theme.colors.secondary,
  },
  graphChangeLabel: {
    fontSize: 10,
    color: 'rgba(199, 196, 215, 0.5)',
    letterSpacing: 0.5,
  },
  graphBars: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    height: 120,
    alignItems: 'flex-end',
  },
  graphBarContainer: {
    alignItems: 'center',
    flex: 1,
  },
  graphBar: {
    width: 18,
    backgroundColor: theme.colors.secondary,
    borderRadius: 999,
    shadowColor: theme.colors.secondary,
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  graphDay: {
    fontSize: 9,
    color: 'rgba(199, 196, 215, 0.3)',
    marginTop: 8,
    letterSpacing: 0.5,
  },
  achHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  achBadge: {
    backgroundColor: 'rgba(208, 188, 255, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 999,
  },
  achCount: {
    fontSize: 11,
    fontWeight: '700',
    color: theme.colors.primary,
  },
  achGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  achCard: {
    width: '48%',
    aspectRatio: 1,
    backgroundColor: theme.colors.surfaceContainer,
    borderRadius: theme.radius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.1)',
  },
  achCardLocked: {
    opacity: 0.4,
    backgroundColor: 'rgba(23, 31, 51, 0.3)',
  },
  achLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: theme.colors.onSurface,
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 13,
  },
  achLabelLocked: {
    color: theme.colors.onSurfaceVariant,
  },
  premiumSection: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: 32,
  },
  premiumGradient: {
    borderRadius: theme.radius.xl,
    backgroundColor: 'linear-gradient(135deg, #d0bcff 0%, #0566d9 100%)',
    overflow: 'hidden',
  },
  premiumContent: {
    padding: 32,
    backgroundColor: '#0566d9',
  },
  premiumHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  premiumBadge: {
    fontSize: 10,
    fontWeight: '700',
    color: '#fff',
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  premiumTitle: {
    fontSize: 26,
    fontWeight: '800',
    color: '#fff',
    lineHeight: 30,
    marginBottom: 20,
  },
  premiumFeatures: {
    marginBottom: 24,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  featureText: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.9)',
    fontWeight: '500',
  },
  premiumButton: {
    backgroundColor: theme.colors.onSurface,
    paddingVertical: 16,
    borderRadius: theme.radius.md,
    alignItems: 'center',
  },
  premiumButtonText: {
    color: theme.colors.surface,
    fontSize: 16,
    fontWeight: '700',
  },
  premiumTrial: {
    fontSize: 10,
    color: 'rgba(255,255,255,0.6)',
    textAlign: 'center',
    marginTop: 12,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  settingsSection: {
    paddingHorizontal: theme.spacing.lg,
    marginTop: 32,
    gap: 4,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 16,
    backgroundColor: theme.colors.surfaceContainerLow,
    borderRadius: theme.radius.md,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  settingText: {
    fontSize: 15,
    fontWeight: '600',
    color: theme.colors.onSurface,
  },
});
