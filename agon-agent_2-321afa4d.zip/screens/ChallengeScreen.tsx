import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView, Alert } from 'react-native';
import { theme } from '../lib/theme';
import CircularTimer from '../components/CircularTimer';
import AnswerButton from '../components/AnswerButton';
import ProgressBar from '../components/ProgressBar';
import { useApp } from '../context/AppContext';
import { hapticSuccess, hapticError, hapticHeavy } from '../lib/haptics';
import { ChallengeQuestion } from '../lib/types';

interface ChallengeScreenProps {
  onComplete: (result: { score: number; accuracy: number; avgSpeed: number; xpGained: number }) => void;
  onExit: () => void;
}

export default function ChallengeScreen({ onComplete, onExit }: ChallengeScreenProps) {
  const { user } = useApp();
  const [timeLeft, setTimeLeft] = useState(60);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [correctCount, setCorrectCount] = useState(0);
  const [totalAnswered, setTotalAnswered] = useState(0);
  const [questionStartTime, setQuestionStartTime] = useState(Date.now());
  const [responseTimes, setResponseTimes] = useState<number[]>([]);

  const questions: ChallengeQuestion[] = [
    { id: 1, a: 18, b: 7, operator: '×', correctAnswer: 126, options: [118, 126, 134, 128], category: 'Math' },
    { id: 2, a: 24, b: 5, operator: '×', correctAnswer: 120, options: [120, 115, 125, 130], category: 'Math' },
    { id: 3, a: 36, b: 4, operator: '÷', correctAnswer: 9, options: [8, 9, 10, 12], category: 'Math' },
    { id: 4, a: 15, b: 8, operator: '+', correctAnswer: 23, options: [21, 22, 23, 24], category: 'Math' },
    { id: 5, a: 42, b: 3, operator: '-', correctAnswer: 39, options: [37, 38, 39, 40], category: 'Math' },
  ];

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + (isAnswered ? 1 : 0)) / questions.length) * 100;

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          handleTimeUp();
          return 60;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentQuestionIndex]);

  useEffect(() => {
    setQuestionStartTime(Date.now());
  }, [currentQuestionIndex]);

  const handleTimeUp = () => {
    hapticHeavy();
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
    } else {
      finishChallenge();
    }
  };

  const handleAnswer = (answer: number) => {
    if (isAnswered) return;

    const responseTime = (Date.now() - questionStartTime) / 1000;
    setResponseTimes(prev => [...prev, responseTime]);
    setSelectedAnswer(answer);
    setIsAnswered(true);

    const isCorrect = answer === currentQuestion.correctAnswer;

    if (isCorrect) {
      hapticSuccess();
      setCorrectCount(prev => prev + 1);
    } else {
      hapticError();
    }

    setTotalAnswered(prev => prev + 1);

    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
        setSelectedAnswer(null);
        setIsAnswered(false);
      } else {
        finishChallenge();
      }
    }, 1200);
  };

  const finishChallenge = () => {
    const accuracy = totalAnswered > 0 ? Math.round((correctCount / totalAnswered) * 100) : 0;
    const avgSpeed = responseTimes.length > 0
      ? Math.round((responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length) * 10) / 10
      : 1.5;
    const score = Math.round((correctCount / questions.length) * 100);
    const xpGained = Math.round(score * 5);

    onComplete({ score, accuracy, avgSpeed, xpGained });
  };

  const getAnswerState = (option: number): 'normal' | 'correct' | 'wrong' => {
    if (!isAnswered) return 'normal';
    if (option === currentQuestion.correctAnswer) return 'correct';
    if (option === selectedAnswer) return 'wrong';
    return 'normal';
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.backgroundGlows}>
        <View style={styles.glow1} />
        <View style={styles.glow2} />
      </View>

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={onExit} style={styles.closeBtn}>
          <Text style={styles.closeIcon}>✕</Text>
        </TouchableOpacity>
        <View style={styles.headerInfo}>
          <Text style={styles.appName}>Synaptic Flow</Text>
          <Text style={styles.level}>Level {user.streak}: Arithmetic Arc</Text>
        </View>
        <View style={styles.streakRow}>
          <View style={styles.streakBadge}>
            <Text style={styles.heart}>❤️</Text>
            <Text style={styles.streakCount}>3</Text>
          </View>
          <View style={styles.streakBadge}>
            <Text style={styles.streakText}>{user.streak} 🔥</Text>
          </View>
        </View>
      </View>

      {/* Timer */}
      <View style={styles.timerSection}>
        <CircularTimer timeLeft={timeLeft} totalTime={60} />
        <View style={styles.streakIndicator}>
          <View style={styles.streakLine} />
          <Text style={styles.streakLabel}>Streak x{correctCount + 1}</Text>
          <View style={styles.streakLine} />
        </View>
      </View>

      {/* Question */}
      <View style={styles.questionSection}>
        <View style={styles.promptBadge}>
          <Text style={styles.promptText}>Calculate Prompt</Text>
        </View>
        <Text style={styles.question}>
          {currentQuestion.a} <Text style={styles.operator}>{currentQuestion.operator}</Text> {currentQuestion.b} <Text style={styles.equals}>= ?</Text>
        </Text>
      </View>

      {/* Answer Grid */}
      <View style={styles.answersGrid}>
        {currentQuestion.options.map((option, index) => (
          <AnswerButton
            key={index}
            answer={option}
            state={getAnswerState(option)}
            onPress={() => handleAnswer(option)}
            disabled={isAnswered}
          />
        ))}
      </View>

      {/* Progress */}
      <View style={styles.progressSection}>
        <ProgressBar
          current={currentQuestionIndex + (isAnswered ? 1 : 0)}
          total={questions.length}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
    paddingHorizontal: theme.spacing.lg,
  },
  backgroundGlows: {
    position: 'absolute',
    inset: 0,
  },
  glow1: {
    position: 'absolute',
    top: '25%',
    left: '25%',
    width: 300,
    height: 300,
    backgroundColor: 'rgba(208, 188, 255, 0.05)',
    borderRadius: 999,
  },
  glow2: {
    position: 'absolute',
    bottom: '25%',
    right: '25%',
    width: 400,
    height: 400,
    backgroundColor: 'rgba(5, 102, 217, 0.05)',
    borderRadius: 999,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 16,
    paddingBottom: 8,
  },
  closeBtn: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeIcon: {
    fontSize: 18,
    color: theme.colors.onSurfaceVariant,
  },
  headerInfo: {
    alignItems: 'center',
  },
  appName: {
    fontSize: 18,
    fontWeight: '900',
    color: theme.colors.primary,
    letterSpacing: -0.5,
  },
  level: {
    fontSize: 10,
    fontWeight: '600',
    color: theme.colors.secondary,
    letterSpacing: 1.5,
    textTransform: 'uppercase',
    opacity: 0.7,
  },
  streakRow: {
    flexDirection: 'row',
    gap: 8,
  },
  streakBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: theme.colors.surfaceContainerHigh,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.1)',
  },
  heart: {
    fontSize: 12,
  },
  streakCount: {
    fontSize: 13,
    fontWeight: '700',
    color: theme.colors.error,
  },
  streakText: {
    fontSize: 13,
    fontWeight: '700',
    color: theme.colors.onSurface,
  },
  timerSection: {
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 24,
  },
  streakIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    marginTop: 8,
  },
  streakLine: {
    width: 48,
    height: 4,
    backgroundColor: theme.colors.secondary,
    borderRadius: 999,
    shadowColor: theme.colors.secondary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 6,
  },
  streakLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: theme.colors.secondary,
    letterSpacing: 2,
    textTransform: 'uppercase',
  },
  questionSection: {
    alignItems: 'center',
    marginBottom: 32,
  },
  promptBadge: {
    paddingHorizontal: 16,
    paddingVertical: 4,
    backgroundColor: theme.colors.surfaceContainerLowest,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(200, 196, 215, 0.05)',
    marginBottom: 16,
  },
  promptText: {
    fontSize: 10,
    fontWeight: '600',
    color: theme.colors.primary,
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  question: {
    fontSize: 56,
    fontWeight: '900',
    color: theme.colors.onSurface,
    letterSpacing: -2,
    textAlign: 'center',
  },
  operator: {
    color: theme.colors.secondary,
    opacity: 0.6,
  },
  equals: {
    color: theme.colors.primary,
  },
  answersGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 16,
    justifyContent: 'center',
    paddingHorizontal: 8,
  },
  progressSection: {
    position: 'absolute',
    bottom: 40,
    left: theme.spacing.lg,
    right: theme.spacing.lg,
  },
});
