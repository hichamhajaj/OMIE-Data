import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useFonts } from 'expo-font';
import { Ionicons } from '@expo/vector-icons';

import { AppProvider } from './context/AppContext';
import { theme } from './lib/theme';
import { hapticMedium } from './lib/haptics';

import OnboardingScreen from './screens/OnboardingScreen';
import HomeScreen from './screens/HomeScreen';
import ChallengeScreen from './screens/ChallengeScreen';
import ResultsScreen from './screens/ResultsScreen';
import ProfileScreen from './screens/ProfileScreen';
import PremiumPaywallScreen from './screens/PremiumPaywallScreen';
import BottomTabBar from './components/BottomTabBar';

const Stack = createNativeStackNavigator();

type TabKey = 'home' | 'training' | 'profile' | 'premium';

interface SessionResult {
  score: number;
  accuracy: number;
  avgSpeed: number;
  xpGained: number;
}

export default function SynapticFlowApp() {
  const [fontsLoaded] = useFonts({
    ...Ionicons.font,
  });

  const [currentScreen, setCurrentScreen] = useState<'onboarding' | 'main'>('onboarding');
  const [activeTab, setActiveTab] = useState<TabKey>('home');
  const [showChallenge, setShowChallenge] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [showPremiumPaywall, setShowPremiumPaywall] = useState(false);
  const [sessionResult, setSessionResult] = useState<SessionResult | null>(null);

  if (!fontsLoaded) {
    return null;
  }

  const handleGetStarted = () => {
    setCurrentScreen('main');
  };

  const handleLogin = () => {
    setCurrentScreen('main');
  };

  const handleStartChallenge = () => {
    setShowChallenge(true);
  };

  const handleChallengeComplete = (result: SessionResult) => {
    setShowChallenge(false);
    setSessionResult(result);
    setShowResults(true);
  };

  const handleChallengeExit = () => {
    setShowChallenge(false);
  };

  const handleResultsContinue = () => {
    setShowResults(false);
    setSessionResult(null);
    setActiveTab('profile');
  };

  const handleResultsUpgrade = () => {
    setShowResults(false);
    setShowPremiumPaywall(true);
  };

  const handleOpenPremium = () => {
    setShowPremiumPaywall(true);
  };

  const handleOpenProfile = () => {
    setActiveTab('profile');
  };

  const handleSubscribe = (planId: string) => {
    setShowPremiumPaywall(false);
    setActiveTab('profile');
  };

  const handleRestore = () => {
    setShowPremiumPaywall(false);
    setActiveTab('profile');
  };

  const handleContinueFree = () => {
    setShowPremiumPaywall(false);
  };

  const renderCurrentTab = () => {
    switch (activeTab) {
      case 'home':
        return (
          <HomeScreen
            onStartChallenge={handleStartChallenge}
            onOpenPremium={handleOpenPremium}
            onOpenProfile={handleOpenProfile}
          />
        );
      case 'training':
        return (
          <HomeScreen
            onStartChallenge={handleStartChallenge}
            onOpenPremium={handleOpenPremium}
            onOpenProfile={handleOpenProfile}
          />
        );
      case 'profile':
        return (
          <ProfileScreen
            onOpenPremium={handleOpenPremium}
          />
        );
      case 'premium':
        return (
          <PremiumPaywallScreen
            onSubscribe={handleSubscribe}
            onRestore={handleRestore}
            onContinueFree={handleContinueFree}
          />
        );
      default:
        return (
          <HomeScreen
            onStartChallenge={handleStartChallenge}
            onOpenPremium={handleOpenPremium}
            onOpenProfile={handleOpenProfile}
          />
        );
    }
  };

  const tabs = [
    { key: 'home', icon: 'home' as const, label: 'Home', active: activeTab === 'home' },
    { key: 'training', icon: 'brain' as const, label: 'Training', active: activeTab === 'training' },
    { key: 'profile', icon: 'person' as const, label: 'Profile', active: activeTab === 'profile' },
    { key: 'premium', icon: 'trophy' as const, label: 'Premium', active: activeTab === 'premium' },
  ];

  const handleTabPress = (key: string) => {
    hapticMedium();
    setActiveTab(key as TabKey);
  };

  if (currentScreen === 'onboarding') {
    return (
      <SafeAreaProvider>
        <StatusBar style="light" />
        <OnboardingScreen
          onGetStarted={handleGetStarted}
          onLogin={handleLogin}
        />
      </SafeAreaProvider>
    );
  }

  if (showChallenge) {
    return (
      <SafeAreaProvider>
        <StatusBar style="light" />
        <ChallengeScreen
          onComplete={handleChallengeComplete}
          onExit={handleChallengeExit}
        />
      </SafeAreaProvider>
    );
  }

  if (showResults && sessionResult) {
    return (
      <SafeAreaProvider>
        <StatusBar style="light" />
        <ResultsScreen
          result={sessionResult}
          onContinue={handleResultsContinue}
          onUpgrade={handleResultsUpgrade}
        />
      </SafeAreaProvider>
    );
  }

  if (showPremiumPaywall) {
    return (
      <SafeAreaProvider>
        <StatusBar style="light" />
        <PremiumPaywallScreen
          onSubscribe={handleSubscribe}
          onRestore={handleRestore}
          onContinueFree={handleContinueFree}
        />
      </SafeAreaProvider>
    );
  }

  return (
    <AppProvider>
      <SafeAreaProvider>
        <StatusBar style="light" />
        <View style={styles.mainContainer}>
          {renderCurrentTab()}
          <BottomTabBar tabs={tabs} onTabPress={handleTabPress} />
        </View>
      </SafeAreaProvider>
    </AppProvider>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
});
