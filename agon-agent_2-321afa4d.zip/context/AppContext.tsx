import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProgress, SessionResult } from '../lib/types';
import { saveData, loadData, STORAGE_KEYS } from '../lib/storage';

interface AppContextType {
  user: UserProgress;
  isPremium: boolean;
  setPremium: (value: boolean) => void;
  updateStreak: (increment?: number) => void;
  addXP: (amount: number) => void;
  completeSession: (result: SessionResult) => void;
  showInterstitialAd: () => boolean;
  resetProgress: () => void;
}

const defaultProgress: UserProgress = {
  isPremium: false,
  streak: 7,
  xp: 2450,
  totalSessions: 42,
  bestScore: 98,
  completedChallenges: [],
  lastSessionDate: null,
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProgress>(defaultProgress);
  const [adCount, setAdCount] = useState(0);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    const savedProgress = await loadData<UserProgress>(
      STORAGE_KEYS.IS_PREMIUM,
      defaultProgress
    );
    setUser(savedProgress);
  };

  const saveUserData = async (newUser: UserProgress) => {
    setUser(newUser);
    await saveData(STORAGE_KEYS.IS_PREMIUM, newUser);
  };

  const setPremium = (value: boolean) => {
    const newUser = { ...user, isPremium: value };
    saveUserData(newUser);
  };

  const updateStreak = (increment = 1) => {
    const newUser = { ...user, streak: user.streak + increment };
    saveUserData(newUser);
  };

  const addXP = (amount: number) => {
    const newUser = { ...user, xp: user.xp + amount };
    saveUserData(newUser);
  };

  const completeSession = (result: SessionResult) => {
    const newUser = {
      ...user,
      totalSessions: user.totalSessions + 1,
      bestScore: Math.max(user.bestScore, result.accuracy),
      completedChallenges: [...user.completedChallenges, result.category],
      lastSessionDate: new Date().toISOString(),
    };
    saveUserData(newUser);
    addXP(result.xpGained);
    if (result.streak > user.streak) {
      updateStreak(1);
    }
  };

  const showInterstitialAd = (): boolean => {
    if (user.isPremium) return false;
    setAdCount(prev => prev + 1);
    return adCount > 0 && adCount % 3 === 0;
  };

  const resetProgress = () => {
    saveUserData(defaultProgress);
    setAdCount(0);
  };

  return (
    <AppContext.Provider
      value={{
        user,
        isPremium: user.isPremium,
        setPremium,
        updateStreak,
        addXP,
        completeSession,
        showInterstitialAd,
        resetProgress,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
